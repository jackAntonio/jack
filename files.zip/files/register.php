<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $sexe = $_POST['sexe'];
    $contact = $_POST['contact'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $code = rand(100000, 999999);

    // Vérification si l'email existe déjà
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows > 0){
        echo "Cet email existe déjà.";
        exit;
    }
    $stmt->close();

    // Insertion de l'utilisateur avec code de validation
    $sql = "INSERT INTO users (nom, email, sexe, contact, password, code, is_verified) VALUES (?, ?, ?, ?, ?, ?, 0)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $nom, $email, $sexe, $contact, $password, $code);
    if($stmt->execute()){
        // Envoi du mail
        require 'send_mail.php';
        sendValidationEmail($email, $code);

        header("Location: verify.php?email=$email");
        exit;
    } else {
        echo "Erreur d'inscription.";
    }
}
?>