<?php
// Configuration pour l'envoi de mail (SMTP)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'jackiningwe@gmail.com');
define('SMTP_PASS', 'uvcv hoim wbeu vdbp');
define('SMTP_FROM', 'jackiningwe@gmail.com');
define('SMTP_FROM_NAME', 'ANTONIO JACK ININGWE');

// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "auth_demo");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>