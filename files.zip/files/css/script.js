const form = document.getElementById('registerForm');
const body = document.body;

form.addEventListener('submit', function () {
  const btn = form.querySelector("button");
  btn.textContent = "Enregistrement...";
  btn.disabled = true;
});

function toggleTheme() {
  const current = body.getAttribute('data-theme');
  const newTheme = current === 'dark' ? 'light' : 'dark';
  body.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
}

window.onload = () => {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    body.setAttribute('data-theme', savedTheme);
  }
};
