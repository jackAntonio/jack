<?php
require 'config.php';

$email = $_GET['email'] ?? '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = $_POST['code'];
    $email = $_POST['email'];

    $sql = "SELECT code FROM users WHERE email = ? AND is_verified = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($db_code);
    if ($stmt->fetch() && $db_code == $code) {
        $stmt->close();
        $sql = "UPDATE users SET is_verified = 1 WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        header("Location: login.php?verified=1");
        exit;
    } else {
        $error = "Code invalide.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Vérification</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="container">
    <form method="POST" id="verifyForm">
      <h2>Vérifiez votre adresse email</h2>
      <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
      <input type="text" name="code" placeholder="Entrez le code" required>
      <button type="submit">Valider</button>
      <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
    </form>
    <button id="themeToggle">Changer de thème</button>
  </div>

  <!-- Modale de succès -->
  <div id="successModal" class="modal">
    <div class="modal-content">
      <h3>✔️ Vérification réussie</h3>
      <p>Votre compte est maintenant actif.</p>
      <a href="login.php"><button>Se connecter</button></a>
    </div>
  </div>

  <script src="js/script.js"></script>
  <?php if ($verified): ?>
    <script>
      document.getElementById("successModal").style.display = "flex";
    </script>
  <?php endif; ?>
</body>
</html>