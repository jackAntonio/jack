<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Accueil</title>
    <style>
        body { font-family: Arial; text-align:center; margin-top:100px;}
    </style>
</head>
<body>
    <h1>Bienvenue, <?= htmlspecialchars($_SESSION['nom']) ?> !</h1>
    <a href="logout.php">Déconnexion</a>
</body>
</html>